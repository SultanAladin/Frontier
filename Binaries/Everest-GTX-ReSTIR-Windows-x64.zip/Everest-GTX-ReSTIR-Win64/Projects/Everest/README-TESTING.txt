PROJECT EVEREST — GTX-FIRST OPTION A VULKAN 1.3 ReSTIR TEST PACKAGE (WINDOWS x64)
====================================================================================

1. STANDALONE DIRECT LAUNCH (ZERO EngineContent/ DEPENDENCY)
   Run:
     Projects\Everest\Everest.exe

   Everest.exe runs 100% standalone from Projects\Everest\Content\ (compiled SPIR-V
   compute kernels, ControlVehicle .facet & .sdfspace archives, authored TextureStudio
   .material + referenced PBR PNG maps, 6-body lunar maps, Hipparcos star catalogue,
   fonts, and icons are automatically staged into Content\ at build time).
   You can move Projects\Everest\ anywhere on disk by itself and run Everest.exe.

2. FRONTIER PROJECT BROWSER + EVEREST HOST
   Run:
     Frontier.exe
   Select "Everest" in the Project Browser (or File -> Open Project -> Everest.projectspace)
   to open the Everest workspace inside the full Frontier editor host.

3. VIEWPORT FLIGHT & QUICK CONTROLS
   - Hold Right Mouse Button (RMB) in the Scene Viewport + W/A/S/D to fly, Q/E (or C/Space)
     for vertical motion, Mouse Wheel to adjust flight speed, Shift (3.0x boost), Ctrl (0.25x).
   - Press 'R' (or click "Reset Cam" in the viewport ribbon) to return to the hero pose.
   - Press 'Escape' to release look capture.
   - Top Viewport Ribbon quick controls (ThemeStructure-bound palette):
       * Renderer  : "ReSTIR GTX" (6-kernel CWBVH + 4-Cascade SDF + ReSTIR DI/GI + GGX VNDF
                     reflections + curved glazing refraction) vs "Preview" (Editor-only fast
                     Cluster-DAG rasterizer + modular shadows).
       * Inspection: Lit Composite, Diffuse GI, Specular Refl, SDF Cone AO, Surface Cards,
                     SDF Cascades, World Normals, Base Albedo, Rough/Metal, Linear Depth,
                     CWBVH Heat, Motion Vecs, Reservoir M, Material Tier, Glass Refract.
       * Quality   : Low / Medium / Ultra, Render Scale (50% / 75% / 100%), and Sun Elevation.
   - Select any of the 22 Default.levelspace records in the Outliner (left) to edit Solar,
     Atmosphere, Clouds, Moons, Fog, SurfaceCards, DistanceField, ThermalBody, ChemicalVessel,
     or HarmonicOscillator live in the Inspector (right).

4. GTX PERFORMANCE & DIAGNOSTIC TELEMETRY LOGS (EDITOR / DEVELOPMENT BUILD)
   While running Everest.exe (or Frontier.exe with Everest open), logs are written live to:
     Projects\Everest\Saved\Logs\EverestDiagnostics.log
     Projects\Everest\Saved\Logs\EverestPerformance.csv
   and the Vulkan pipeline cache is persisted atomically to:
     Projects\Everest\Saved\PipelineArchive\ComputePipelines.bin

   Send back EverestDiagnostics.log and EverestPerformance.csv after your GTX test run!
