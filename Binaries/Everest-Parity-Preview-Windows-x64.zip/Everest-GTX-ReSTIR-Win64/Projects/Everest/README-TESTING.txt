EVEREST WINDOWS X64 — UNSIGNED PARITY WORK-IN-PROGRESS

Source revision: 1ceec08bee26047d07c56b434dee3c259cb04f9e

Extract the entire archive. Launch Projects\Everest\Everest.exe for Everest,
or Frontier.exe to open Everest in the Frontier hub. Vulkan 1.3 driver required.

This is not a 1:1 Webdemo port. Screen-depth traversal, ReSTIR GI reservoirs,
reference surface cards, display TAA/exposure and environment integration remain.
Built on Linux with Zig 0.13.0. No Windows startup, Radeon GPU, antivirus scan,
or publisher-signature verification was performed. The executables are unsigned.
